# Landing Page Project

## Table of Contents


   1.  Filling empty unordered list
   2.  Mobile functionality
   3.  Active state Navbar
   4.  Active state viewport
   5.  Dynamic adding of new section
   
   
   
   
  1.1
  
  Creating a new section and adding attributes so that it looks like the others
  
  1.2
  
  Creating a side-stripe that appears when screen gets smaller. On click a sidebar appears that has been hidden with translateX.
  
  1.3 
  
  Removing all classes and then adding class to that specific navbar item with event listener. 
  
  1.4
  
  Removing all classes and then adding class to that specific section with event listener. 
  
  1.5 
  
  Creating a for loop that fills navbar list dependent on the number of sections. 
  
  

